class FirestoreConstants {
  static const userCollection = 'users';
  static const drinkCollection = 'drinks';
  static const notificationCollection = 'notifications';
}
