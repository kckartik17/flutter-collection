class BlocBase {
  void dispose() {}
}
