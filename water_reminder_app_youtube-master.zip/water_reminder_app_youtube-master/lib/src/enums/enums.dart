enum PopupMenuChoices { signOut, themeChanger, syncPopup }
